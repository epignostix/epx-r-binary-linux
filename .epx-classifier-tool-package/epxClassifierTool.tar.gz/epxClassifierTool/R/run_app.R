#' Run epxCNS Classifier app
#'
#' This function launches the Shiny application for the epxCNS Classifier.
#'
#' @export
#' @importFrom shiny runApp
#'
#' @examples
#' if(interactive()) {
#'   run_cns_app()
#' }


run_classifier_tool <- function() {
  appDir <- system.file("app", package = "epxClassifierApp")
  if (appDir == "") {
    stop("Could not find app directory. Try reinstalling 'epxClassifierApp'.", call. = FALSE)
  }

  shiny::runApp(appDir, display.mode = "normal", launch.browser=TRUE)
}