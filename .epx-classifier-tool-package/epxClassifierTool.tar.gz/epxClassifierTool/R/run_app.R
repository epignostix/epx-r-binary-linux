#' Run epxCNS Classifier app
#'
#' This function launches the Shiny application for the epxCNS Classifier.
#'
#' @export
#' @importFrom shiny runApp
#'
#' @examples
#' if(interactive()) {
#'   run_cns_app()
#' }


run_classifier_tool <- function() {
  appDir <- system.file("app", package = "epxClassifierTool")
  if (appDir == "") {
    stop("Could not find app directory. Try reinstalling 'epxClassifierTool'.", call. = FALSE)
  }

  shiny::runApp(appDir, display.mode = "normal", launch.browser=TRUE, port=5000)
}