# Utility functions

#' Clean up temporary directories
#' @param temp_dir Path to temporary directory
cleanupTempFiles <- function(temp_dir = file.path(getwd(), ".temp")) {
  if (dir.exists(temp_dir)) {
    unlink(temp_dir, recursive = TRUE)
  }
}


#' Validate IDAT files for batch mode
#' @param files Vector of file names
#' @return List containing validation status and message
validateIdatFiles <- function(files) {
  if (length(files) <= 1) {
    return(list(
      valid = FALSE,
      message = "Select both Red and Grn array"
    ))
  }
  
  are_idat_files <- all(grepl("\\.idat$", files, ignore.case = TRUE))
  if (!are_idat_files) {
    return(list(
      valid = FALSE,
      message = "All selected files must be IDAT files (.idat extension)"
    ))
  }
  
  
  sample_names <- unique(sub("_(Red|Grn)\\.idat$", "", files, ignore.case = TRUE))
  for (sample_name in sample_names) {
    red_file <- paste0(sample_name, "_Red.idat")
    grn_file <- paste0(sample_name, "_Grn.idat")
    
    if (!(red_file %in% files) || !(grn_file %in% files)) {
      return(list(
        valid = FALSE,
        message = paste("Missing Red or Grn file for sample", sample_name)
      ))
    }
  }
  return(list(
    valid = TRUE,
    sample_names = sample_names
  ))
}