# Functions to install classifiers based on selected type

package_name <- NULL
package_file <- NULL

# Function to check if package is installed
is_package_installed <- function(pkg) {
    if(pkg == "CNS") pkg <- "epxCNS"
    if(pkg == "SARCOMA") pkg <- "epxSARCOMA"
    if(pkg == "SAMPLE") pkg <- "sampleRpackage"
    return(pkg %in% rownames(installed.packages()))
}

# Function to install package if not already installed
install_if_missing <- function(packages, repos = "https://cran.r-project.org/") {
    for (pkg in packages) {
        if (!is_package_installed(pkg)) {
            cat("Installing", pkg, "...\n")
            install.packages(pkg, repos = repos, dependencies = TRUE)
        } else {
            cat(pkg, "is already installed. Version:", as.character(packageVersion(pkg)), "\n")
        }
    }
}


# Function to install Bioconductor packages if not already installed
install_bioc_if_missing <- function(packages) {
    # Check if BiocManager is installed first
    if (!is_package_installed("BiocManager")) {
        cat("Installing BiocManager...\n")
        install.packages("BiocManager", repos = "https://cran.r-project.org/")
    } else {
        cat("BiocManager is already installed. Version:", as.character(packageVersion("BiocManager")), "\n")
    }

    for (pkg in packages) {
        if (!is_package_installed(pkg)) {
            cat("Installing Bioconductor package", pkg, "...\n")
            BiocManager::install(pkg)
        } else {
            cat("Bioconductor package", pkg, "is already installed. Version:", as.character(packageVersion(pkg)), "\n")
        }
    }
}

# Function to install package from private git repository
check_and_install_epx_r_package_from_git <- function(repo_url, subdir = "", ref = "main", force = FALSE) {
    # Check if devtools is installed
    if (!is_package_installed("devtools")) {
        cat("Installing devtools...\n")
        install.packages("devtools", repos = "https://cran.r-project.org/")
    }
    
    # Extract package name from repo URL or subdir
    if (subdir != "") {
        pkg_name <- basename(subdir)
    } else {
        pkg_name <- basename(repo_url)
        pkg_name <- gsub("\\.git$", "", pkg_name)
    }
    
    # Check if package is already installed
    if (!force && is_package_installed(pkg_name)) {
        cat(pkg_name, "is already installed. Version:", as.character(packageVersion(pkg_name)), "\n")
        return(TRUE)
    }
    
    # Install from git repository
    tryCatch({
        cat("Installing", pkg_name, "from git repository...\n")
        if (subdir != "") {
            devtools::install_git(repo_url, subdir = subdir, ref = ref, dependencies = TRUE, force = TRUE)
            cat("Successfully installed", pkg_name, "\n")
            return(TRUE)
        } else {
            devtools::install_git(repo_url, ref = ref, dependencies = TRUE, force = TRUE)
            cat("Successfully installed", pkg_name, "\n")
            return(TRUE)
        }
        return(FALSE)
    }, error = function(e) {
        cat("Error installing", pkg_name, ":", e$message, "\n")
        return(FALSE)
    })
}


# Main installation function
# Main installation function
install_classifier <- function(selected_classifier) {
    # Validate input
    if (!selected_classifier %in% c("SAMPLE", "CNS", "SARCOMA")) {
        stop("Error: selected_classifier must be either 'SAMPLE', 'CNS' or 'SARCOMA'")
    }

    cat("Installing", selected_classifier, "classifier...\n")

    # Use withProgress for installation steps
    withProgress(message = paste('Installing', selected_classifier, 'Classifier'), value = 0, {
        
        # Step 1: Install common dependencies
        incProgress(0.1, detail = "Installing common dependencies...")
        cat("Step 1: Checking and installing common dependencies...\n")
        common_packages <- c(
            "randomForest", "glmnet", "ggplot2", "ggridges", "magrittr",
            "tidyr", "gt", "patchwork", "gridExtra", "knitr", "uwot",
            "kableExtra", "plotly", "tinytex"
        )
        install_if_missing(common_packages)

        # Step 2: Install common Bioconductor packages
        incProgress(0.1, detail = "Installing Bioconductor packages...")
        cat("Step 2: Checking and installing common Bioconductor packages...\n")
        common_bioc_packages <- c("GenomicFeatures", "DNAcopy", "illuminaio")
        install_bioc_if_missing(common_bioc_packages)

        # Step 3: Install the classifier package from epx git repo
        incProgress(0.3, detail = paste("Installing", selected_classifier, "classifier package..."))
        cat("Step 3: Installing", selected_classifier, "classifier package...\n")
        
        success <- FALSE
        if (selected_classifier == "SAMPLE") {
            package_name <<- "SAMPLE"
            package_file <<- "sampleRpackage"
            repo <- "https://github.com/asif-epignostix/epx-r-installer-download-resource.git"
            success <- check_and_install_epx_r_package_from_git(repo, subdir = package_file, ref = "main", force = FALSE)

        } else if (selected_classifier == "CNS") {
            package_name <<- "epxCNS"
            package_file <<- ""
            repo <- ""
            success <- FALSE

        } else if (selected_classifier == "SARCOMA") {
            package_name <<- "epxSARCOMA"
            package_file <<- ""
            repo <- ""
            success <- FALSE
        }

        if (!success) {
            stop(paste("Failed to install", selected_classifier, "classifier package"))
        }

        # Step 4: Finalization
        incProgress(0.7, detail = "Finalizing installation...")
        cat("Installation completed successfully!\n")
        
        # Complete
        incProgress(1.0, detail = "Installation completed!")
    })
    
    return(TRUE)
}


# Example usage:
# install_classifier("CNS")
# install_classifier("SARCOMA")
