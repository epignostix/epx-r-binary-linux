# Functions to install classifiers based on selected type

package_name <- NULL
package_file <- NULL

# Function to check if package is installed
is_package_installed <- function(pkg) {
    return(pkg %in% rownames(installed.packages()))
}

# Function to install package if not already installed
install_if_missing <- function(packages, repos = "https://cran.r-project.org/") {
    for (pkg in packages) {
        if (!is_package_installed(pkg)) {
            cat("Installing", pkg, "...\n")
            install.packages(pkg, repos = repos, dependencies = TRUE)
        } else {
            cat(pkg, "is already installed. Version:", as.character(packageVersion(pkg)), "\n")
        }
    }
}

# Function to install Bioconductor packages if not already installed
install_bioc_if_missing <- function(packages) {
    # Check if BiocManager is installed first
    if (!is_package_installed("BiocManager")) {
        cat("Installing BiocManager...\n")
        install.packages("BiocManager", repos = "https://cran.r-project.org/")
    } else {
        cat("BiocManager is already installed. Version:", as.character(packageVersion("BiocManager")), "\n")
    }
    
    for (pkg in packages) {
        if (!is_package_installed(pkg)) {
            cat("Installing Bioconductor package", pkg, "...\n")
            BiocManager::install(pkg)
        } else {
            cat("Bioconductor package", pkg, "is already installed. Version:", as.character(packageVersion(pkg)), "\n")
        }
    }
}

# Main installation function
install_classifier <- function(selected_classifier) {
    # Validate input
    if (!selected_classifier %in% c("CNS", "SARCOMA")) {
        stop("Error: selected_classifier must be either 'CNS' or 'SARCOMA'")
    }
    
    cat("Installing", selected_classifier, "classifier...\n")
    
    # Step 1: Install common dependencies
    cat("Step 1: Checking and installing common dependencies...\n")
    common_packages <- c("randomForest", "glmnet", "ggplot2", "ggridges", "magrittr", 
                        "tidyr", "gt", "patchwork", "gridExtra", "knitr", "uwot", 
                        "kableExtra", "plotly", "tinytex")
    install_if_missing(common_packages)
    
    # Step 2: Install common Bioconductor packages
    cat("Step 2: Checking and installing common Bioconductor packages...\n")
    common_bioc_packages <- c("GenomicFeatures", "DNAcopy", "illuminaio")
    install_bioc_if_missing(common_bioc_packages)
    
    

    
    # Step 3: Install the classifier package from epx git repo
    cat("Step 4: Installing", selected_classifier, "classifier package...\n")
    # TODO: if CNS, then install from
    
    
    cat("Installation completed successfully!\n")
    cat(package_name, "package is ready to use.\n")
    return()
}

# Example usage:
# install_classifier("CNS")
# install_classifier("SARCOMA")