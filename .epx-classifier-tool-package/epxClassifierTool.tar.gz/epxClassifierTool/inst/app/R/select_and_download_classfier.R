source('R/install_classifier.R')
source('R/classifier_page.R')

# Available classifiers configuration
AVAILABLE_CLASSIFIERS <- list(
  "epxCNS" = list(
    name = "CNS Classifier",
    package_name = "epxCNS",
    git_repo = "https://github.com/example/epxCNS", # Update with actual repo URL,
    is_installed = FALSE
  ),
  "epxSARCOMA" = list(
    name = "Sarcoma Classifier", 
    package_name = "epxSARCOMA",
    git_repo = "https://github.com/example/epxSARCOMA", # Update with actual repo URL
    is_installed = FALSE
  )
)

# UI for classifier selection page
classifier_selection_ui <- function() {
  fluidPage(
    # Header
    fluidRow(
      style = "padding: 20px; margin: 0px; background-color: #f8f9fa; border-radius: 5px;",
      column(
        width = 6,
        tags$div(
          style = "height: 100px; display: flex; align-items: center;",
          tags$h4("Download Heidelberg Epignostix Classifier", 
                 style = "margin: 0; font-size: 24px;")
        )
      ),
      column(
        width = 6,
        tags$img(src = "Epignostix-logo-cropped.svg", 
                 style = "float: right; height: 80px; margin-right: 30%;")
      )
    ),
    
    hr(style = "margin: 20px 0;"),
    
    # TODO: progress bar for download and install
    # if installed, next button to redirect to 'classifier_page('CNS')'
    # Classifier selection
    fluidRow(
      column(
        width = 8, offset = 2,
        selectInput("classifier_type", 
                   "Select Classifier to Install:",
                   choices = c("CNS" = "CNS", "Sarcoma" = "SARCOMA"),
                   selected = "CNS"),
        
        # Progress bar for download and install
        # conditionalPanel(
        #   condition = "input.install_classifier > 0",
        #   div(
        #     style = "margin: 20px 0;",
        #     h4("Installation Progress:"),
        #     progressBar(
        #       id = "install_progress",
        #       value = 0,
        #       total = 100,
        #       title = "Installing classifier...",
        #       display_pct = TRUE,
        #       striped = TRUE,
        #       status = "info"
        #     ),
        #     textOutput("install_status")
        #   )
        # ),
        
        # Action buttons
        fluidRow(
          column(
            width = 6,
            actionButton("install_classifier", 
                        "Install Classifier",
                        class = "btn-primary btn-lg",
                        style = "width: 100%; margin: 10px 0;")
          ),
          column(
            width = 6,
            # Next button to redirect to classifier page (shown when installed)
            conditionalPanel(
              condition = "output.classifier_installed",
              actionButton("proceed_to_classifier",
                          "Proceed to Classifier",
                          class = "btn-success btn-lg",
                          style = "width: 100%; margin: 10px 0;")
            )
          )
        )
      )
    )
  )
}

# Server logic for classifier selection
classifier_selection_server <- function(input, output, session, selected_classifier) {
  # Reactive values to track installation state
  values <- reactiveValues(
    installing = FALSE,
    installed = FALSE,
    status_message = ""
  )
  
  # Check if classifier is already installed
  observe({
    if (!is.null(input$classifier_type)) {
      pkg_name <- ifelse(input$classifier_type == "CNS", "epxCNS", "epxSARCOMA")
      values$installed <- is_package_installed(pkg_name)
      
      if (values$installed) {
        values$status_message <- paste(pkg_name, "is already installed and ready to use!")
      }
    }
  })
  
  # Install classifier when button is clicked
  observeEvent(input$install_classifier, {
    if (!values$installing && !values$installed) {
      values$installing <- TRUE
      values$status_message <- "Starting installation..."
      
      # Call the install function (which now includes withProgress)
      tryCatch({
        install_classifier(input$classifier_type)
        
        # Installation completed successfully
        values$status_message <- "Installation completed successfully!"
        values$installed <- TRUE
        values$installing <- FALSE
        
        showNotification(
          paste(input$classifier_type, "classifier installed successfully!"),
          type = "success",
          duration = 5
        )
        
      }, error = function(e) {
        values$status_message <- paste("Installation failed:", e$message)
        values$installing <- FALSE
        showNotification(
          paste("Installation failed:", e$message),
          type = "error",
          duration = 10
        )
      })
    }
  })
  
  # Output for installation status
  output$install_status <- renderText({
    values$status_message
  })
  
  # Status indicator UI
  output$status_indicator <- renderUI({
    if (values$installing) {
      div(
        style = "text-align: center; margin: 10px 0;",
        tags$i(class = "fa fa-spinner fa-spin", style = "font-size: 24px; color: #007bff;"),
        br(),
        tags$small("Installing... Please wait.")
      )
    } else if (values$installed) {
      div(
        style = "text-align: center; margin: 10px 0;",
        tags$i(class = "fa fa-check-circle", style = "font-size: 24px; color: #28a745;"),
        br(),
        tags$small("Installation completed successfully!")
      )
    }
  })
  
  # Output to control visibility of proceed button
  output$classifier_installed <- reactive({
    values$installed
  })
  outputOptions(output, "classifier_installed", suspendWhenHidden = FALSE)
  
  # Handle proceed to classifier button
  observeEvent(input$proceed_to_classifier, {
    # Update the selected_classifier reactive value
    selected_classifier(input$classifier_type)
    
    # Show success notification
    showNotification(
      paste("Proceeding to", input$classifier_type, "classifier..."),
      type = "success",
      duration = 3
    )
  })
  
  return(list(
    installed = reactive(values$installed),
    classifier_type = reactive(input$classifier_type)
  ))
}