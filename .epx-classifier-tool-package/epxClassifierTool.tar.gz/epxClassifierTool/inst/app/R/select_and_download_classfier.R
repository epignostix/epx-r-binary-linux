# Available classifiers configuration
AVAILABLE_CLASSIFIERS <- list(
  "epxCNS" = list(
    name = "CNS Classifier",
    package_name = "epxCNS",
    git_repo = "https://github.com/example/epxCNS", # Update with actual repo URL,
    is_installed = FALSE
  ),
  "epxSARCOMA" = list(
    name = "Sarcoma Classifier", 
    package_name = "epxSARCOMA",
    git_repo = "https://github.com/example/epxSARCOMA", # Update with actual repo URL
    is_installed = FALSE
  )
)

# UI for classifier selection page
classifier_selection_ui <- function() {
  fluidPage(
    # Header
    fluidRow(
      style = "padding: 20px; margin: 0px; background-color: #f8f9fa; border-radius: 5px;",
      column(
        width = 6,
        tags$div(
          style = "height: 100px; display: flex; align-items: center;",
          tags$h4("Select Heidelberg Epignostix Classifier", 
                 style = "margin: 0; font-size: 24px;")
        )
      ),
      column(
        width = 6,
        tags$img(src = "Epignostix-logo-cropped.svg", 
                 style = "float: right; height: 80px; margin-right: 30%;")
      )
    ),
    
    hr(style = "margin: 20px 0;"),
    
    # Classifier selection
    fluidRow(
      column(
        width = 8, offset = 2,
        wellPanel(
          tags$h4("Choose Classifier Package"),
          selectInput(
            "classifier_dropdown",
            "Select Classifier:",
            choices = setNames(
              names(AVAILABLE_CLASSIFIERS),
              sapply(AVAILABLE_CLASSIFIERS, function(x) x$name)
            ),
            selected = NULL
          ),
          
        )
      ),
      column(
        # Next button - only show when package is installed
        conditionalPanel(
          condition = "input.classifier_dropdown != ''",
          uiOutput("package_status_ui")
        )
        # Next button - only show when package is installed
        conditionalPanel(
          condition = "input.classifier_dropdown != ''",
          uiOutput("next_button_ui")
        )
      )
    )
  )
}

# Server logic for classifier selection
classifier_selection_server <- function(input, output, session, selected_classifier) {
  
  
}

# Main UI function that switches between selection and classifier page
# main_ui <- function() {
#   conditionalPanel(
#     condition = "!output.show_classifier_page",
#     classifier_selection_ui()
#   )
# }

# Main server function
# main_server <- function(input, output, session) {
#   # Initialize reactive values
#   selected_classifier <- initClassifierReactiveValue()$selected_classifier
  
#   # Classifier selection server
#   show_classifier_page <- classifier_selection_server(
#     input, output, session, selected_classifier
#   )
  
#   # Output to control conditional panel
#   output$show_classifier_page <- reactive({
#     show_classifier_page()
#   })
#   outputOptions(output, "show_classifier_page", suspendWhenHidden = FALSE)
  
#   # Return selected classifier for use in other parts of app
#   return(selected_classifier)
# }