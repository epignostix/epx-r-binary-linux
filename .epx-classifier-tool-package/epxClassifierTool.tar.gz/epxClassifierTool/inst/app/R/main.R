# UI Components
# source("R/inputSamplePage.R")
# source("R/selectClassifierPage.R")
source("R/classifier_page.R")
source("R/select_and_download_classfier.R")

# Main UI
ui <- fluidPage(
  useShinyjs(),
  add_busy_spinner(spin = "fading-circle"),
  
  # tabPanel("Input Sample", classifier_page(selected_classifier = "CNS"))
  # tabPanel("Select Classifier", classifier_selection_ui())
  conditionalPanel(
    condition = "!output.show_classifier_page",
    classifier_selection_ui()
  )
  
)
# Main server function
main_server <- function(input, output, session) {
  # Initialize reactive values
  selected_classifier <- initClassifierReactiveValue()$selected_classifier
  
  # Classifier selection server
  show_classifier_page <- classifier_selection_server(
    input, output, session, selected_classifier
  )
  
  # Output to control conditional panel
  output$show_classifier_page <- reactive({
    classifier_page(selected_classifier=)
  })
  outputOptions(output, "show_classifier_page", suspendWhenHidden = FALSE)
  
  # Return selected classifier for use in other parts of app
  return(selected_classifier)
}