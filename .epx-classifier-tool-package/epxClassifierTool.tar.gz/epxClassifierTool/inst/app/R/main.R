# UI Components
# source("R/inputSamplePage.R")
# source("R/selectClassifierPage.R")
source("R/classifier_page.R")
source("R/select_and_download_classfier.R")

# Main UI
ui <- fluidPage(
  useShinyjs(),
  add_busy_spinner(spin = "fading-circle"),
  
  # tabPanel("Input Sample", classifier_page(selected_classifier = "CNS"))
  # tabPanel("Select Classifier", classifier_selection_ui())
  classifier_selection_ui()
  
  
)
# Main server function
server <- function(input, output, session) {
  
  # Classifier selection server
  classifier_selection_server(
    input, output, session, selected_classifier
  )

}