classifier_page <- function(selected_classifier = NULL) {
  column(
    width = 12,
    # header row with logo and title
    fluidRow(
      style = "padding: 20px; margin: 0px; background-color: #f8f9fa; border-radius: 5px;",
      column(
        # title
        width = 6,
        tags$div(
          style = "height: 100px; display: flex; align-items: center;",
          tags$h4("Heidelberg Epignostix Methylation Classifier", 
                 style = "margin: 0; font-size: 24px;") # TODO text size
        )
      ),
      column(
        # logo
        width = 6,
        tags$img(src = "Epignostix-logo-cropped.svg", 
                 style = "float: right; height: 80px; margin-right: 30%;") # Adjust height as needed
      )
    ),
    fluidRow(
      style = "margin: 10px 0;",
      column(
        width = 12,
        actionButton("back_to_classifier", 
                    "← Back to Classifier Selection", 
                    class = "btn-secondary",
                    style = "margin-bottom: 10px;")
      )
    ),
    

    hr(style = "margin: 20px 0;"),

    conditionalPanel(
      condition = "!input.use_test_files",
      
      
      
      # inputs and instruction row
      fluidRow(
        # idat input column
        column(
          width = 6,
          fileInput("idats", "Choose IDAT Files (Select RED and GRN array files for samples):",
                   multiple = TRUE,
                   accept = c(".idat")
          ),
          textInput("sample_count", "Sample Count:")
        ),
        
        # instruction column
        column(
          width = 6,
          tags$div(
            style = "padding: 10px; margin: 20px; background-color: #f8f9fa; border-radius: 5px;",
            tags$p("Select one or multiple samples,"),
            tags$p("Click 'Generate' to process all selected samples and get reports for them."),
            tags$p("Note: RED and GRN array file names should be - sample-id followed by _Red.idat and _Grn.idat")
          )
        )
      )
    ),
    
    # Keep the existing conditional panel for test files
    conditionalPanel(
      condition = "input.use_test_files",
      tags$div(
        style = "padding: 10px; margin: 20px; background-color: #f8f9fa; border-radius: 5px;",
        tags$h4("Test Files Information:"),
        tags$p("The following test files will be processed:"),
        tags$ul(
          tags$li("450k array: Sample ", TEST_SAMPLE_IDS$`450k`),
          tags$li("EPIC array: Sample ", TEST_SAMPLE_IDS$EPIC),
          tags$li("EPICv2 array: Sample ", TEST_SAMPLE_IDS$EPICv2)
        ),
        tags$p("Click 'Generate' to process all test files.")
      ),
      selectInput("array_type", "Select Array Type:",
                 choices = VALID_ARRAY_TYPES)
    ),
    
    hr(),
    
    selectInput("report_type", "Select Report Format:",
                choices = VALID_REPORT_TYPES,
                selected = "html"),
    actionButton("generate", "Generate"),
    downloadButton("downloadReport", "Download Report", style = "display: none;"),
    actionButton("reset", "Reset", style = "display: none;"),
    hr(),
    checkboxInput("use_test_files", "Use test samples given in the epxCNS classifier package", value = FALSE)
  )
}