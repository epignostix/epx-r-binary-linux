#' Generate single report
#' @param idat_dir Directory containing IDAT files
#' @param sample_id Sample ID
#' @param report_type Type of report (html/pdf)
#' @param temp_download_dir Directory for temporary downloads
#' @return List containing report information
classify_single_sample <- function(idat_dir, sample_id, report_type, temp_download_dir) {
  if(require(epxCNS)) packageVersion('epxCNS')
  
  tryCatch({
    showNotification(
      sprintf("Processing %s", sample_id),
      type = "message",
      duration = 30
    )
    
    # Read methylation array data
    sample_rg <- read_methylarray(file.path(idat_dir, sample_id))
    report_dir <- file.path(temp_download_dir, paste0("report_", sample_id))
    
    # Generate report
    epxCNS::report(sample_rg, output_type = report_type, output_dir = report_dir)
    
    showNotification(
      sprintf("Report created for %s", sample_id),
      type = "message",
      duration = 30
    )
    
    return(list(
      success = TRUE,
      file_path = file.path(report_dir, paste0(sample_id, ".", report_type)),
      sample_id = sample_id
    ))
    
  }, error = function(e) {
    showNotification(
      "Error in process to generate report",
      type = "error",
      duration = 30
    )
    return(list(
      success = FALSE,
      message = e$message
    ))
  })
}

