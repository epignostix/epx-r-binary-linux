# Initialize reactive values
initReactiveValues <- function() {
  list(
    report_info = reactiveValues(
      markdown_to_render = NULL,
      download_file_path = NULL,
      sample_id = NULL
    ),
    rv = reactiveValues(
      sample_names = NULL,
      temp_download_dir = file.path(getwd(), ".temp", "dl"),
      temp_upload_dir = file.path(getwd(), ".temp", "ul"),
      report_type = "html",
      cancel_processing = FALSE
    )
  )
}

initClassifierReactiveValue <- function() {
  list(
    selected_classifier = reactiveValues(
      name = NULL,
      package_name = NULL,
      repo = NULL,
      is_installed = FALSE
    )
  )
}