# TODO: fix issues
# R/check_dependencies.R

#' Check and install required packages
#' @return List with status of checks and any error messages
check_dependencies <- function() {
  # List of required CRAN packages
  cran_packages <- c(
    "shiny",
    "shinyjs",
    "shinyFiles",
    "shinybusy",
    "testthat",  # for running tests
    "devtools"   # for installing from GitHub if needed
  )
  
  # List of required Bioconductor packages
  bioc_packages <- c(
    "minfi",     # assuming epxCNS depends on these
    "BiocStyle"
  )
  
  results <- list(
    status = TRUE,
    messages = character(),
    missing_packages = character()
  )
  
  # Function to safely check if a package is installed
  is_package_installed <- function(package) {
    return(package %in% installed.packages()[,"Package"])
  }
  
  # Check CRAN packages
  missing_cran <- cran_packages[!sapply(cran_packages, is_package_installed)]
  if (length(missing_cran) > 0) {
    results$status <- FALSE
    results$missing_packages <- c(results$missing_packages, missing_cran)
    results$messages <- c(results$messages,
                         sprintf("Missing CRAN packages: %s",
                                paste(missing_cran, collapse = ", ")))
  }
  
  # Check if BiocManager is installed
  if (!is_package_installed("BiocManager")) {
    results$status <- FALSE
    results$missing_packages <- c(results$missing_packages, "BiocManager")
    results$messages <- c(results$messages,
                         "BiocManager is not installed. Required for Bioconductor packages.")
  } else {
    # Check Bioconductor packages
    missing_bioc <- bioc_packages[!sapply(bioc_packages, is_package_installed)]
    if (length(missing_bioc) > 0) {
      results$status <- FALSE
      results$missing_packages <- c(results$missing_packages, missing_bioc)
      results$messages <- c(results$messages,
                           sprintf("Missing Bioconductor packages: %s",
                                  paste(missing_bioc, collapse = ", ")))
    }
  }
  
  # Check epxCNS package
  if (!is_package_installed("epxCNS")) {
    results$status <- FALSE
    results$missing_packages <- c(results$missing_packages, "epxCNS")
    results$messages <- c(results$messages,
                         "epxCNS package is not installed.")
  }
  
  return(results)
}

#' Install missing dependencies
#' @param missing_packages Character vector of package names to install
#' @return List with installation status and messages
install_dependencies <- function(missing_packages) {
  results <- list(
    status = TRUE,
    messages = character()
  )
  
  if (length(missing_packages) == 0) {
    results$messages <- c(results$messages, "No packages need to be installed.")
    return(results)
  }
  
  # Install BiocManager if needed
  if ("BiocManager" %in% missing_packages) {
    tryCatch({
      install.packages("BiocManager")
      results$messages <- c(results$messages, "Successfully installed BiocManager.")
      missing_packages <- missing_packages[missing_packages != "BiocManager"]
    }, error = function(e) {
      results$status <- FALSE
      results$messages <- c(results$messages,
                           sprintf("Failed to install BiocManager: %s", e$message))
      return(results)
    })
  }
  
  # Install CRAN packages
  cran_packages <- missing_packages[!missing_packages %in% c(bioc_packages, "epxCNS")]
  if (length(cran_packages) > 0) {
    tryCatch({
      install.packages(cran_packages)
      results$messages <- c(results$messages,
                           sprintf("Successfully installed CRAN packages: %s",
                                  paste(cran_packages, collapse = ", ")))
    }, error = function(e) {
      results$status <- FALSE
      results$messages <- c(results$messages,
                           sprintf("Failed to install some CRAN packages: %s", e$message))
    })
  }
  
  # Install Bioconductor packages
  bioc_packages <- intersect(missing_packages, bioc_packages)
  if (length(bioc_packages) > 0) {
    tryCatch({
      BiocManager::install(bioc_packages)
      results$messages <- c(results$messages,
                           sprintf("Successfully installed Bioconductor packages: %s",
                                  paste(bioc_packages, collapse = ", ")))
    }, error = function(e) {
      results$status <- FALSE
      results$messages <- c(results$messages,
                           sprintf("Failed to install some Bioconductor packages: %s", e$message))
    })
  }
  
  # Install epxCNS if needed
  if ("epxCNS" %in% missing_packages) {
    tryCatch({
      devtools::install_github("your-github-repo/epxCNS")  # Replace with actual repo
      results$messages <- c(results$messages, "Successfully installed epxCNS package.")
    }, error = function(e) {
      results$status <- FALSE
      results$messages <- c(results$messages,
                           sprintf("Failed to install epxCNS package: %s", e$message))
    })
  }
  
  return(results)
}