# UI Components
# source("R/inputSamplePage.R")
# source("R/selectClassifierPage.R")
source("R/classifier_page.R")

# Main UI
ui <- fluidPage(
  useShinyjs(),
  add_busy_spinner(spin = "fading-circle"),
  
  # select classifier
  # tabsetPanel(
  #   tabPanel("Input Sample", selectClassifierPage.R())
  # )

  # check if classifier is selected or not

  # tabPanel("Select Classifier", select_classifier_page())
  
  tabPanel("Input Sample", classifier_page(selected_classifier = "CNS"))
  
)