source("R/reactive.R")
source("R/utils.R")
source("R/classify.R")
source("global.R")

classifier_server <- function(input, output, session) {
  shinyjs::disable("sample_count")
  # Initialize reactive values
  reactive_values <- initReactiveValues()
  report_info <- reactive_values$report_info
  rv <- reactive_values$rv
  session_id = reactiveValues(
    id = NULL
  )

  # Add cleanup on session end
  onStop(function() {
    cleanupTempFiles()
  })


  shinyjs::disable("generate")
  # Reset observer
  observeEvent(
    input$reset,
    {
      # Set cancel flag to true
      rv$cancel_processing <- TRUE
      
      
      if (!input$use_test_files) {
        shinyjs::enable("generate")
      } 
      shinyjs::enable("report_type")
      shinyjs::hide("downloadReport")
      shinyjs::reset("idats")
      shinyjs::reset("sample_count")
      shinyjs::reset("report_type")
      shinyjs::enable("report_type")
      shinyjs::hide("reset")
      shinyjs::show("use_test_files")
      
      # Reset cancel flag
      rv$cancel_processing <- FALSE

      # remove the ul and dl files in .temp
      cleanupTempFiles()

      showNotification(
        "Process reset",
        type = "message",
        duration = 10
      )
    }
  )


  # Download report 
  output$downloadReport <- downloadHandler(
        filename = function() {
          shinyjs::enable("reset")
          if (length(rv$sample_names) == 1) {
            basename(file.path(rv$temp_download_dir, paste0("report_", rv$sample_names[1]), paste0(rv$sample_names[1], ".", rv$report_type)))
          } else {
            paste0("mnp_reports_", format(Sys.time(), "%Y%m%d_%H%M%S"), ".zip")
          }
        },
        content = function(file) {
          withProgress(
            message = "Preparing download",
            value = 0,
            {
              # Disable download button during process
              shinyjs::disable("downloadReport")
              
              if (length(rv$sample_names) == 1) {
                incProgress(0.3, detail = "Copying report file...")
                file.copy(
                  file.path(rv$temp_download_dir, 
                        paste0("report_", rv$sample_names[1]), 
                          paste0(rv$sample_names[1], ".", rv$report_type)), 
                  file, 
                  recursive = FALSE
                )
            } else {
                incProgress(0.3, detail = "Creating ZIP archive...")
                current_dir <- getwd()
                setwd(rv$temp_download_dir)
                zip(file, files = list.files(recursive = TRUE), flags = "-r9X")
                setwd(current_dir)
              }
              
              incProgress(0.7, detail = "Finalizing download...")
              
              # Enable download button after completion
              shinyjs::enable("downloadReport")
            }
          )
          shinyjs::enable("reset")
        },
        contentType = "auto"
      )
  
  # Generate report observer
  observeEvent(
    input$generate,
    {
      shinyjs::disable("generate")
      shinyjs::disable("report_type")
      shinyjs::hide("use_test_files")
      
      # Reset report info
      report_info$markdown_to_render <- NULL
      report_info$file_path_to_download <- NULL
      report_info$sample_id <- NULL
      
      # cleanupTempFiles()
      

      tryCatch({
        
        if (input$use_test_files) {
          shinyjs::enable("report_type")
          path <- file.path(path.package('mnp.v12epicv2'), "ext")
          test_sample_id <- TEST_SAMPLE_IDS[[input$array_type]]
          cat(path)
          withProgress(message = "Classifying test sample", value = 0, {
            incProgress(0.4, detail = "Processing test files...")
            result <- classify_single_sample(path, test_sample_id, input$report_type, rv$temp_download_dir)
          })
            
            
          if (result$success) {
            cat("----- success ----")
            incProgress(0.4, detail = "Finalizing report...")
            report_info$file_path_to_download <- result$file_path
            report_info$sample_id <- result$sample_id
            incProgress(0.2, detail = "Completed...")
            cat("----- completed ----")
            showNotification(
              sprintf("Processing complete"),
              type = "message",
              duration = 15
            )
            shinyjs::show("downloadReport")
            shinyjs::show("reset")
          }
        } else {

          if (!dir.exists(rv$temp_download_dir)) {
            dir.create(rv$temp_download_dir, recursive = TRUE)
          }
          if (!dir.exists(rv$temp_upload_dir)) {
            dir.create(rv$temp_upload_dir, recursive = TRUE)
          }
          withProgress(message = "Uploading sample(s)", value = 0, {
              
            # Copy uploaded files
            lapply(seq_along(input$idats$datapath), function(i) {
              file.copy(input$idats$datapath[i],
                        file.path(rv$temp_upload_dir, input$idats$name[i]),
                        overwrite = TRUE)
            })
              
                
            if (!is.null(rv$sample_names)) {
              n <- length(rv$sample_names)
              processed_count <- 0
              failed_count <- 0
              # ... (previous batch processing code)
              incProgress(0.2, detail = "Sample uploaded...")
              for (i in seq_along(rv$sample_names)) {
                sample_id <- rv$sample_names[i]
                
                incProgress(
                  amount = 0.6/n,
                  message = sprintf("Processing samples (%d/%d)", i, n),
                  detail = sprintf("Current: %s | Success: %d | Failed: %d", 
                                  sample_id, processed_count, failed_count)
                )
                
                tryCatch({
                  result <- classify_single_sample(
                    rv$temp_upload_dir,
                    sample_id,
                    input$report_type,
                    rv$temp_download_dir
                  )
                  c
                  if (result$success) processed_count <- processed_count + 1
                }, error = function(e) {
                  failed_count <- failed_count + 1
                  showNotification(
                    sprintf("Error processing sample %s: %s", sample_id, e$message),
                    type = "error",
                    duration = 15
                  )
                })
              }
              
              incProgress(0.2, detail = "Finalizing reports...")
              report_info$file_path_to_download <- rv$temp_download_dir
                
              showNotification(
                sprintf("Processing complete: %d successful, %d failed", 
                        processed_count, failed_count),
                type = if(failed_count == 0) "message" else "warning",
                duration = 15
              )
                  
              if (processed_count > 0) {
                shinyjs::show("downloadReport")
              } else {
                showNotification(
                  "Process Count = 0",
                  type = "error",
                  duration = 15
                )
              }
            }
          })    
        }
      }, error = function(e) {
        showNotification(
          "Error generating report",
          type = "error",
          duration = 15
        )
        # cleanupTempFiles()
      })
      # shinyjs::enable("generate") 
    }
  )

  # File input validation observer
  observeEvent(input$idats, {
    if (!is.null(input$idats) && !input$use_test_files) {
      
      files <- input$idats$name
      
      validation <- validateIdatFiles(files)
      if (!validation$valid) {
        showNotification(validation$message, type = "error", duration = 15)
        shinyjs::reset("idats")
      } else {
        rv$sample_names <- validation$sample_names
        updateTextInput(session, "sample_count", value = length(rv$sample_names))
      }
      shinyjs::enable("report_type")
      # Enable reset button for removing uploaded samples
      shinyjs::show("reset")
      shinyjs::enable("generate")
    }
  })
  
  # Process mode observer
  observeEvent(input$process_mode, {
    shinyjs::reset("idats")
  })

  observeEvent(input$use_test_files, {
    if (!input$use_test_files) {
        shinyjs::disable("generate")
      }
    else {
      shinyjs::enable("generate")
    }
  })
}