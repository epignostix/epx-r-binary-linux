source("R/reactive.R")
source("R/input_sample_page.R")
source("R/install_classifier.R")

select_classifier_page <- function() {
  fluidPage(
    titlePanel("Select Classifier"),
    
    fluidRow(
      column(
        width = 8,
        offset = 2,
        
        wellPanel(
          h3("Choose a Classifier", class = "text-center"),
          br(),
          
          # Classifier selection
          radioButtons(
            inputId = "selected_classifier",
            label = "Available Classifiers:",
            choices = list(
              "CNS" = "CNS",
              "Sarcoma" = "SARCOMA"
            ),
            selected = character(0),
            width = "100%"
          ),
          
          br(),
          
          # Classifier description
          conditionalPanel(
            condition = "input.selected_classifier == 'CNS'",
            div(
              class = "alert alert-info",
              h4("CNS Classifier"),
              p("This classifier is designed for Central Nervous System tumor classification.",
                "It analyzes gene expression patterns to classify CNS tumors into different subtypes.")
            )
          ),
          
          conditionalPanel(
            condition = "input.selected_classifier == 'SARCOMA'",
            div(
              class = "alert alert-info", 
              h4("Sarcoma Classifier"),
              p("This classifier is designed for Sarcoma tumor classification.",
                "It analyzes gene expression patterns to classify Sarcoma tumors into different subtypes.")
            )
          ),
          
          br(),
          
          # Action buttons
          div(
            class = "text-center",
            actionButton(
              inputId = "proceed_to_input",
              label = "Proceed to Sample Input",
              class = "btn btn-primary btn-lg",
              disabled = TRUE
            ),
            br(), br(),
            actionButton(
              inputId = "back_to_home",
              label = "Back to Home",
              class = "btn btn-secondary"
            )
          )
        )
      )
    )
  )
}

# Server logic for classifier selection
select_classifier_server <- function(input, session) {
  classifier_reactive_values <- initClassifierReactiveValue()
  # Enable/disable proceed button based on selection
  observe({
    if (!is.null(input$selected_classifier) && input$selected_classifier != "") {
      classifier_reactive_values$selected_classifier$name <- input$selected_classifier
    }
  })
  
  # check classifier package installation
  install_classifier(input$selected_classifier)
  
  
  # implement navigation to inputSamplePage
  observeEvent(input$proceed_to_input, {
    if (!is.null(input$selected_classifier)) {
      updateTabsetPanel(session, "main_tabs", selected = "Input Sample")
      hide(select_classifier_page())
      show(classifier_page(selected_classifier = input$selected_classifier))
    }
  })

}
