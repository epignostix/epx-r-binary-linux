
# Source dependency checker
# source("R/check_dependencies.R")


# Load required packages
library(shiny)
library(shinyjs)
library(shinyFiles)
library(shinybusy)

# Set global options
options(scipen = 999)
options(shiny.trace = TRUE)
# max upload or download size 100 MB
options(shiny.maxRequestSize = 50000*1024^2)

# Global constants
VALID_REPORT_TYPES <- c("HTML" = "html", "PDF" = "pdf")

VALID_ARRAY_TYPES <- c("450k", "EPIC", "EPICv2")

# Test file sample IDs
TEST_SAMPLE_IDS <- list(
  "450k" = "c3c169f6-2cf3-5c87-8605-135eb0592492",
  "EPIC" = "abe0abbe-caaf-5e90-9517-f6002432eea3",
  "EPICv2" = "206891110004_R01C01"
)