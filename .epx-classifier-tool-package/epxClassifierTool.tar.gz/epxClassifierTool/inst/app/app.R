library(shiny)
library(shinyjs)
library(shinyFiles)
library(shinybusy)

# Source all components
source("global.R")
source("R/ui.R")
source("R/server.R")


# Run the application
shinyApp(ui = ui, server = server)