library(shiny)
library(shinyjs)
library(shinyFiles)
library(shinybusy)

# Source all components
source("global.R")
source("R/ui.R")
source("R/classifier_server.R")


# Run the application
# https://pkgs.rstudio.com/shiny/reference/shinyApp.html
shinyApp(ui = ui, server = classifier_server)